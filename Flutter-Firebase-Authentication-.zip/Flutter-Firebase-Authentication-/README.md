# irA - FoodDonation App

![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/0.1.png?raw=true)

### What is irA
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/0.2.png?raw=true)

### irA Flow Chart
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/0.3.png?raw=true)


## Application Snapshots.....

### Login Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/1.png?raw=true)

### Home Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/2.jpg?raw=true)

### Food Upload Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/3.0.jpg?raw=true)
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/3.1.jpg?raw=true)

### History Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/3.2.jpg?raw=true)

### Available Food Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/4.0.jpg?raw=true)

### Food details Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/4.1.jpg?raw=true)

### Redeem Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/5.1.jpg?raw=true)

### Donate money Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/5.2.jpg?raw=true)

### Contact Page
![alt text](https://github.com/krishnapal2545/irrA/blob/master/ScreenShot/5.3.jpg?raw=true)
